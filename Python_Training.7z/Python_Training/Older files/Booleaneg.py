class Booleaneg:
    string_example = "Johan"
    string_example_1 = '12121212'

    is_nums = string_example.islower()

    if (is_lower): # means if is lower = true
        print("Lower chars found")

    print("Test end")