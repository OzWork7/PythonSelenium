class DictionaryEg:
#     wheels = 4
#     color_main = "blue"
#     color_roof = 'white'
#     engine = "Eiesel"
#     Price = 250

    car = {
        'shells':4,
        'color main':'blue',
        'color_roof' : "white",
        'brand' : 'Ford'
 }

    print(car['brand'])
    print(car['color main'])