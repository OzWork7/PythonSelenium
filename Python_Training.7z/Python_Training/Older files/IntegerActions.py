class integerActions():

    a=1
    b=5
    c= 12


    sum = a+b
    diff= a-b
    dev = a/b
    multiple = a+b
    modulo = c%b
    print(modulo)
    print(f'the value of mudolo is{modulo}')

    class stringActions():
        s="fdd"