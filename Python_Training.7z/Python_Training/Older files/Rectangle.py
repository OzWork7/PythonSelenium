class Rectangle():

    width = 5
    height = 10

    area_of_Rectangle=width*height
    print(f'area is ',area_of_Rectangle)

    circumference_of_Rectangle=width*2+height*2
    print(f'circumference is {circumference_of_Rectangle}')