first_name = "Jeff"
last_name = 'Cohen'
age = 99
age_as_string = str(age)
# casting the integer to string

print(first_name + ' ' + last_name)
print(f'first_name+' '+last_name', age)
print("My name is " + first_name + " " + "ma name is " + age_as_string)

string_with_nums = '4'
string_nums_as_int = int(string_with_nums)
num2 = 2
sum = string_nums_as_int + num2
print(f'the summary is {sum} my name is {first_name}')
