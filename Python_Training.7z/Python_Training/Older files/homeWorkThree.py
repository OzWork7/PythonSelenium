class homeWorkThree:
    list = [5,80,1,9,56,71,25,38]
    listL=len(list)

    for x in list()