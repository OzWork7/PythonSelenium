class homeWorkTwo:
    fName = 'Oz'
    lName = 'Gabay'
    fullN=(f'{fName} {lName}')
    x= len(fullN)

    for y in range(0,x,1):
        print(fullN[y:])


    print('End of run')