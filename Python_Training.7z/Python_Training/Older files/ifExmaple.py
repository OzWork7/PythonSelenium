class ifExample():
    i = 2
    if (i == 2):
        print("I is equal to 2")
        i = i + 4

    else:
        print("I is not 2")
    print("Test end")

    print("multiple if")
    if (i == 3):
        print("I was equals to 3")
    elif (i == 4):
        print("I was 4")
    elif (i == 5):
        print("I was 5")

    else:
        print("I was no at define")
