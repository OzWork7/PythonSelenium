class square_Two:
    x = 0
    for x in range(x, 10, 1):
        if (x * x == x * 4):
            if (x != 0):
                break
        else:
            continue
    print(x)
