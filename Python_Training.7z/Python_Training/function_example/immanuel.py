class immanuel:
    print("This "+1+1+ok+" meme")