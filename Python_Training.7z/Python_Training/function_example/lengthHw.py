from Python_Training import utils


class lengthHw:
    fName = 'Oz'
    lName = 'Gabay'
    fullN=(f'{fName} {lName}')
    x= utils.length_And_Print(fullN)
