class person:

    def age_calculator(self,age):
        if (age>18):
            print("age is above 18")
        else:
            print("Student age is lower than 18")

    def age_printing_into_person(self,age):
        print(age)