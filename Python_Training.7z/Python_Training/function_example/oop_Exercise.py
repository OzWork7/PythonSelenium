class oop_Exercise:
    set_in_db_legs()
    set_in_db_tail(is tail)
    calc_distance(speed,time)

