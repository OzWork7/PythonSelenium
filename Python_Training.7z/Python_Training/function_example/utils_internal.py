class utils_internal:
    