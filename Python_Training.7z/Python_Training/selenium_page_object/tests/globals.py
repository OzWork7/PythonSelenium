url = "https://www.saucedemo.com/"
user_text = "standard_user"
pw_text = "secret_sauce"