urlSamsung = "https://www.samsung.com/us/"
